/**
 * 伏羲平台凭证管理模块
 * 存储位置: ~/.fuxi-credentials.json
 * 注意: 密码使用 base64 编码存储，非加密，仅防止偶然窥视
 */
const fs = require('fs');
const path = require('path');
const os = require('os');

const CREDENTIALS_FILE = path.join(os.homedir(), '.fuxi-credentials.json');

/**
 * 获取凭证文件路径
 * @returns {string}
 */
function getCredentialsPath() {
  return CREDENTIALS_FILE;
}

/**
 * 读取凭证
 * @returns {{ apiUrl: string, username: string, password: string } | null}
 */
function getCredentials() {
  if (!fs.existsSync(CREDENTIALS_FILE)) {
    return null;
  }

  try {
    const data = JSON.parse(fs.readFileSync(CREDENTIALS_FILE, 'utf-8'));
    return {
      apiUrl: data.apiUrl || 'http://8.145.49.128',
      username: data.username,
      password: Buffer.from(data.password, 'base64').toString('utf-8')
    };
  } catch (e) {
    console.error('[WARN] 读取凭证文件失败:', e.message);
    return null;
  }
}

/**
 * 保存凭证
 * @param {{ apiUrl: string, username: string, password: string }} creds
 */
function saveCredentials(creds) {
  const data = {
    apiUrl: creds.apiUrl || 'http://8.145.49.128',
    username: creds.username,
    password: Buffer.from(creds.password).toString('base64'),
    lastUpdated: new Date().toISOString()
  };

  fs.writeFileSync(CREDENTIALS_FILE, JSON.stringify(data, null, 2), {
    mode: 0o600  // 仅当前用户可读写
  });

  console.log(`[INFO] 凭证已保存至: ${CREDENTIALS_FILE}`);
}

/**
 * 清除凭证
 */
function clearCredentials() {
  if (fs.existsSync(CREDENTIALS_FILE)) {
    fs.unlinkSync(CREDENTIALS_FILE);
    console.log('[INFO] 凭证已清除');
  }
}

/**
 * 检查凭证是否存在
 * @returns {boolean}
 */
function hasCredentials() {
  return fs.existsSync(CREDENTIALS_FILE);
}

module.exports = {
  getCredentialsPath,
  getCredentials,
  saveCredentials,
  clearCredentials,
  hasCredentials
};
