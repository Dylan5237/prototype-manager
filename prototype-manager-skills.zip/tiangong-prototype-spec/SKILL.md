---
name: tiangong-prototype-spec
description: A general-purpose B-end (enterprise) frontend design specification for Vue 3 + Element Plus prototypes. Provides consistent visual style (gradient header, flat tabs, high-contrast borders), layout patterns (sidebar + tree + detail panel), and interaction guidelines. Suitable for management dashboards, data management systems, and enterprise applications across all domains.
---

# 天宫原型规范（Tiangong Prototype Specification）

通用的企业级（B 端）前端设计规范，适用于 Vue 3 + Element Plus 技术栈。

## 核心原则

1. **Vue 3 + Element Plus + TypeScript + Vite** 技术栈
2. **去斑马纹、高对比度边框、扁平化页签** 的视觉风格
3. **操作按钮统一右下角** 的交互原则
4. **清晰的信息层级** 与一致的用户体验
5. **每个原型必须包含原型说明系统**：说明面板 + 左侧高亮区块 + 悬停高亮连线；主页面时面板在右侧，弹窗/抽屉打开时面板自动移到左侧（详见[原型说明系统](#原型说明系统)章节）

## 快速检查清单（每次生成原型前必读）

- [ ] Header 使用渐变 `#2b5ffa -> #1e4bdb`，高度 48px，右上角 Bell 图标**无红色角标**
- [ ] 表格必须 `border size="small"`，**禁止 `stripe`**，操作列 `fixed="right"`
- [ ] 页签 active 状态使用 `#2b5ffa` 下划线/背景
- [ ] 主操作按钮放在 `.bottom-action-bar` 中，右对齐
- [ ] 详情弹窗宽度 `520px`，操作弹窗宽度 `720px`，均 `align-center`
- [ ] 必填项 label 用自定义 slot，红色星号 `<span class="star">*</span>`
- [ ] 树形控件层级清晰，文件夹与叶子节点使用不同图标颜色
- [ ] 页面结构遵循：Header → Sidebar → Content → Tree Panel → Detail Panel
- [ ] 是否为每个主要功能区块添加了 `.proto-element` 类和 `data-proto-id` 属性
- [ ] 说明面板宽度是否 340px，背景 `#fffbe6`；主页面时在右侧（左边框虚线 `#fa8c16`），弹窗/抽屉打开时自动移到左侧（右边框虚线 `#fa8c16`）并提升 `z-index: 2100`
- [ ] 悬停时左侧区块、右侧说明项、连线是否正常联动；连线中间是否有编号标签
- [ ] 弹窗打开时是否切换到弹窗的独立说明内容（通过 `data-proto-id` 属性切换）

## 设计系统

### 颜色

参见 [references/color-palette.md](references/color-palette.md)

### 布局

参见 [references/layout-patterns.md](references/layout-patterns.md)

### 组件

参见 [references/component-patterns.md](references/component-patterns.md)

### 交互

参见 [references/interaction-patterns.md](references/interaction-patterns.md)

## 原型说明系统

所有原型必须内嵌原型说明系统。完整规范与代码模板参见 [references/prototype-annotation.md](references/prototype-annotation.md)。

### 基本要求

- **说明面板**：固定宽度 340px，浅黄色背景（`#fffbe6`）
  - 主页面模式：位于右侧，橙色虚线左边框（`#fa8c16`）
  - 弹窗/抽屉模式：通过 `modal-mode` 类自动定位到左侧（`left: 0`），橙色虚线右边框，并设置 `z-index: 2100` 以浮于 Element Plus 遮罩之上
- **左侧高亮区块**：各功能区块添加 `.proto-element` 类，悬停时整体高亮（蓝色阴影 + 浅蓝背景）
- **悬停交互**：悬停说明项或左侧区块时，两侧同时高亮，显示带编号标签的蓝色贝塞尔连线
- **弹窗说明**：弹窗/抽屉打开时，通过切换 `data-proto-id` 属性将说明系统切换到弹窗的独立说明内容；`ProtoAnnotation.drawConnections()` 需根据 `modal-mode` 动态判断面板在左/右，调整连线起点/终点

### 生成原型的步骤

1. 分析页面结构，识别所有主要功能区块（统计、筛选、表格、操作栏、弹窗区域等）
2. 为每个区块编写说明项（编号、4-8 字标题、30-60 字描述）
3. 在 DOM 中为区块容器添加 `class="proto-element"` 和 `data-proto-id` 属性
4. 将原有 `.app-wrapper > .main-body` 整体迁入 `.prototype-wrapper > .main-body`
5. 在 `.prototype-wrapper` 内并排放置 `.annotation-panel`
6. 定义 `mainAnnotations` 和弹窗对应的 `dialogAnnotations` 数组
7. 嵌入 `ProtoAnnotation` 纯 JS 引擎，在 `onMounted` 中初始化
8. 在弹窗打开/关闭的 `watch` 中调用 `switchToModalMode` / `switchToMainMode`

## 典型页面结构速查

### 主页面框架（App.vue，含原型说明系统）

```vue
<template>
  <div id="app">
    <!-- 48px gradient header（全宽，在 prototype-wrapper 之外） -->
    <div class="top-header">...</div>

    <div class="prototype-wrapper">
      <!-- 左侧主体 -->
      <div class="main-body">
        <div class="global-sidebar">...</div>
        <div class="content-area">
          <div class="page-tabs">...</div>
          <div class="page-content">
            <div class="tree-panel">...</div>
            <div class="detail-panel">
              <!-- 功能区块示例：带 proto-element 和 data-proto-id -->
              <div class="stats-section proto-element" data-proto-id="1">
                <!-- 统计卡片内容 -->
              </div>
              <div class="filter-section proto-element" data-proto-id="2">
                <!-- 筛选栏内容 -->
              </div>
              <div class="table-section proto-element" data-proto-id="3">
                <!-- info-header + el-tabs + scroll-table-area + bottom-action-bar -->
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 说明面板（主页面在右侧，弹窗/抽屉打开时通过 JS/CSS 自动移到左侧） -->
      <div class="annotation-panel">
        <div class="annotation-panel-inner">
          <div class="annotation-panel-header">
            <span class="annotation-badge">PROTOTYPE</span>
            <span class="annotation-title">原型说明</span>
          </div>
          <div class="annotation-hint">以下内容为界面元素的功能说明，悬停左侧对应区域可高亮连线。</div>
          <div class="annotation-section-title">
            <el-icon><List /></el-icon>
            <span id="desc-title">功能说明</span>
          </div>
          <div id="main-descs" class="annotation-list">
            <div
              v-for="item in mainAnnotations"
              :key="item.id"
              class="proto-desc"
              :data-proto-id="item.marker"
            >
              <div class="proto-number">{{ item.marker }}</div>
              <div class="proto-content">
                <div class="proto-item-title">{{ item.title }}</div>
                <div class="proto-item-desc">{{ item.desc }}</div>
              </div>
            </div>
          </div>
          <div id="modal-descs" class="annotation-list" style="display: none;">
            <div
              v-for="item in dialogAnnotations"
              :key="item.id"
              class="proto-desc"
              :data-proto-id="item.marker"
            >
              <div class="proto-number">{{ item.marker }}</div>
              <div class="proto-content">
                <div class="proto-item-title">{{ item.title }}</div>
                <div class="proto-item-desc">{{ item.desc }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- SVG 连线层 -->
    <svg id="proto-connections" class="proto-svg-layer"></svg>

    <!-- dialogs（弹窗内使用 modal-proto-element） -->
  </div>
</template>
```

### 详情页内部布局（DetailPage.vue）

```vue
<template>
  <div class="detail-page">
    <div class="info-bar">...</div>
    <div class="sub-tabs-bar">...</div>
    <div class="filter-bar">...</div>
    <div class="table-wrap">...</div>
    <div class="pagination-bar">...</div>
    <div class="bottom-actions">...</div>
  </div>
</template>
```

## 关键 CSS 常量

```css
/* 颜色 */
--primary: #2b5ffa;
--header-gradient-start: #2b5ffa;
--header-gradient-end: #1e4bdb;
--page-bg: #f5f7fa;
--card-bg: #ffffff;
--table-header-bg: #fafafa;
--info-bar-bg: #f6f7fb;
--border-main: #e8e8e8;
--border-sub: #f0f0f0;
--text-title: #262626;
--text-body: #595959;
--text-meta: #8c8c8c;

/* 尺寸 */
--header-height: 48px;
--sidebar-width: 180px;
--tree-width: 220px;
--overview-nav-width: 44px;
```

## 常见错误规避

1. **不要在表格外部再包一层带 `overflow:auto` 的容器然后放 bottom-action-bar**，这会导致按钮需要滚动才能看到。正确做法：`.tab-pane-body { display:flex; flex-direction:column; }` + `.scroll-table-area { flex:1; overflow:auto; }` + `.bottom-action-bar { flex-shrink:0; }`

2. **不要把详情页的切换器放在公共头部**。页面级切换器应放在对应内容区域内。

3. **不要在 el-table 的 #append slot 里放按钮**。这会破坏表格边框连续性，应使用外部 `.bottom-action-bar`。

4. **树面板与详情面板的职责分离**：左侧树负责层级导航，右侧详情面板负责数据展示与操作，避免在树中放置过多操作按钮。

5. **不要把 `.annotation-panel` 放进 `.main-body` 内部**。它必须是 `.prototype-wrapper` 的直接子元素，与 `.main-body` 并列。

6. **不要遗漏弹窗的说明内容**。每个弹窗/抽屉都应有独立的 `dialogAnnotations` 数组，并正确实现 `switchToModalMode` / `switchToMainMode` 函数来切换 `data-proto-id`。`switchToModalMode()` 中必须将 `.annotation-panel` 设置为 `position: fixed; left: 0; z-index: 2100`，否则弹窗打开时说明面板会遮挡弹窗内容或被遮罩压在下方。

7. **SVG 连线层 `#proto-connections` 必须在 `#app` 内部、`.prototype-wrapper` 之外**。如果放在 `.prototype-wrapper` 内部，会被 `overflow: hidden` 裁切，导致连线不可见。
