# 天宫原型规范 - 布局模式

## 全局框架（App.vue 级）

所有页面必须采用以下结构：

```
.app-wrapper
├── .top-header (48px, flex, gradient #2b5ffa -> #1e4bdb)
│   ├── .header-left (logo + 系统名称 + 主导航)
│   └── .header-right (Bell图标无角标 + user-info + Lock + Setting)
├── .main-body (flex:1, overflow:hidden)
│   ├── .global-sidebar (180px, 白底, 左侧导航)
│   ├── .content-area (flex:1, flex-col)
│   │   ├── .page-tabs (顶部页签栏, 灰底 #f5f7fa)
│   │   └── .page-content (flex:1, padding:0 12px 12px, gap:12px)
│   │       ├── .tree-panel (220px, 白底, 边框, 树结构)
│   │       └── .detail-panel (flex:1, 白底, 边框, 内容区)
```

## 详情面板内部布局

### 标准详情面板结构

```
.detail-panel
├── .info-header (#f6f7fb背景, 显示标题+元信息+tags)
└── .panel-content
    ├── el-tabs.main-tabs (列表/统计/设置等)
    │   └── el-tab-pane
    │       └── .tab-pane-body (display:flex; flex-direction:column; height:100%)
    │           ├── .scroll-table-area (flex:1; overflow:auto; 表格区)
    │           └── .bottom-action-bar (justify-content:flex-end; 按钮区)
```

### 带侧边导航的详情面板

适用于需要从多个维度查看数据的场景：

```
.detail-body (display:flex; height:100%)
├── .side-nav (width:44px; 垂直文字导航)
│   └── .side-nav-item (writing-mode:vertical-rl; 维度A/维度B/维度C/维度D)
└── .content-table-wrap (flex:1; display:flex; flex-direction:column; overflow:hidden)
    ├── .toolbar (筛选栏/操作栏)
    └── el-table (height="100%" 或包裹在 scroll-table-area 内)
```

### 底部按钮

所有主操作按钮必须放在 `.bottom-action-bar` 中：

```css
.bottom-action-bar {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding: 12px 0 0;
  flex-shrink: 0;
}
```

## 详情页内部布局（DetailPage.vue）

DetailPage.vue 采用从上到下的严格层级：

```
.detail-page (display:flex; flex-direction:column; height:100%)
├── .info-bar (标题+标识、创建时间、状态切换、返回链接)
├── .sub-tabs-bar (二级页签切换)
├── .filter-bar (筛选条件行)
├── .table-wrap (flex:1; overflow:auto; 表格)
├── .pagination-bar (分页)
└── .bottom-actions (底部操作按钮)
```

## 关键约束

1. **表格必须带边框**：`border` + `size="small"`
2. **表格去除斑马纹**：不设置 `stripe`
3. **操作列固定右侧**：`fixed="right"`
4. **所有面板用直角**：`border-radius: 0`（不使用圆角卡片）
5. **内容区不产生双层滚动**：tab-pane-body 用 flex column，表格放在 scroll-table-area 内
