#!/usr/bin/env node
/**
 * 天宫技能包初始化脚本
 * 功能:
 *   1. 配置伏羲平台账号凭证（首次运行或凭证失效时）
 *   2. 安装三个技能所需的所有依赖
 *
 * 用法:
 *   node setup.js              # 交互式初始化
 *   node setup.js --reset      # 重新配置凭证
 *   node setup.js --deps-only  # 仅安装依赖
 */
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { execSync } = require('child_process');

const SKILLS_DIR = __dirname;
const credentials = require('./shared/credentials');

// ─── 交互式输入 ───────────────────────────────────────────

function createReadline() {
  return readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
}

function ask(rl, question, defaultValue) {
  return new Promise((resolve) => {
    const prompt = defaultValue
      ? `${question} [${defaultValue}]: `
      : `${question}: `;
    rl.question(prompt, (answer) => {
      resolve(answer.trim() || defaultValue || '');
    });
  });
}

function askHidden(rl, question) {
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      // 换行（因为 readline 不会自动换行）
      process.stdout.write('\n');
      resolve(answer.trim());
    });
  });
}

// ─── 凭证配置 ─────────────────────────────────────────────

async function setupCredentials(reset) {
  console.log('\n═══════════════════════════════════════');
  console.log('  伏羲平台凭证配置');
  console.log('═══════════════════════════════════════\n');

  if (credentials.hasCredentials() && !reset) {
    const existing = credentials.getCredentials();
    console.log(`当前凭证:`);
    console.log(`  平台地址: ${existing.apiUrl}`);
    console.log(`  用户名:   ${existing.username}`);
    console.log(`  凭证文件: ${credentials.getCredentialsPath()}`);
    console.log('');
    console.log('如需重新配置，请运行: node setup.js --reset');
    return true;
  }

  const rl = createReadline();

  try {
    const apiUrl = await ask(rl, '伏羲平台地址', 'http://8.145.49.128');
    const username = await ask(rl, '用户名');
    if (!username) {
      console.error('[ERROR] 用户名不能为空');
      return false;
    }
    const password = await askHidden(rl, '密码: ');
    if (!password) {
      console.error('[ERROR] 密码不能为空');
      return false;
    }

    credentials.saveCredentials({ apiUrl, username, password });
    console.log('[OK] 凭证配置完成');
    return true;
  } finally {
    rl.close();
  }
}

// ─── 依赖安装 ─────────────────────────────────────────────

function installDependencies() {
  console.log('\n═══════════════════════════════════════');
  console.log('  依赖安装');
  console.log('═══════════════════════════════════════\n');

  let allOk = true;

  // 1. fuxi-packager 需要 adm-zip
  const fuxiPackagerDir = path.join(SKILLS_DIR, 'fuxi-packager');
  const fuxiPackagerPkg = path.join(fuxiPackagerDir, 'package.json');

  if (fs.existsSync(fuxiPackagerPkg)) {
    console.log('[1/1] 安装 fuxi-packager 依赖 (adm-zip)...');
    try {
      execSync('npm install --production', {
        cwd: fuxiPackagerDir,
        stdio: 'inherit'
      });
      console.log('[OK] fuxi-packager 依赖安装完成\n');
    } catch (e) {
      console.error(`[ERROR] fuxi-packager 依赖安装失败: ${e.message}\n`);
      allOk = false;
    }
  }

  // 2. deployment-validator 和 tiangong-prototype-spec 无需 npm 依赖
  console.log('[INFO] deployment-validator: 无需额外依赖（使用 Node.js 内置模块 + PowerShell）');
  console.log('[INFO] tiangong-prototype-spec: 纯文档规范，无需依赖');

  return allOk;
}

// ─── 环境检查 ─────────────────────────────────────────────

function checkEnvironment() {
  console.log('\n═══════════════════════════════════════');
  console.log('  环境检查');
  console.log('═══════════════════════════════════════\n');

  let allOk = true;

  // Node.js
  try {
    const nodeVersion = execSync('node --version', { encoding: 'utf-8' }).trim();
    console.log(`[OK] Node.js: ${nodeVersion}`);
  } catch (e) {
    console.error('[FAIL] Node.js 未安装或不在 PATH 中');
    allOk = false;
  }

  // npm
  try {
    const npmVersion = execSync('npm --version', { encoding: 'utf-8' }).trim();
    console.log(`[OK] npm: ${npmVersion}`);
  } catch (e) {
    console.error('[FAIL] npm 未安装或不在 PATH 中');
    allOk = false;
  }

  // PowerShell (Windows)
  try {
    const psVersion = execSync('powershell -Command "$PSVersionTable.PSVersion.Major"', {
      encoding: 'utf-8', stdio: 'pipe'
    }).trim();
    console.log(`[OK] PowerShell: ${psVersion}`);
  } catch (e) {
    console.error('[FAIL] PowerShell 不可用（deployment-validator 需要）');
    allOk = false;
  }

  // Git (可选)
  try {
    const gitVersion = execSync('git --version', { encoding: 'utf-8' }).trim();
    console.log(`[OK] Git: ${gitVersion}`);
  } catch (e) {
    console.log('[WARN] Git 未安装（fuxi-packager 的版本描述功能需要 Git）');
  }

  // adm-zip
  const admZipPath = path.join(SKILLS_DIR, 'fuxi-packager', 'node_modules', 'adm-zip');
  if (fs.existsSync(admZipPath)) {
    console.log('[OK] adm-zip: 已安装');
  } else {
    console.log('[WARN] adm-zip: 未安装（将尝试安装）');
  }

  return allOk;
}

// ─── 主流程 ───────────────────────────────────────────────

async function main() {
  const args = process.argv.slice(2);
  const reset = args.includes('--reset');
  const depsOnly = args.includes('--deps-only');

  console.log('\n╔═══════════════════════════════════════╗');
  console.log('║   天宫技能包初始化工具               ║');
  console.log('║   伏羲平台 · 原型管理               ║');
  console.log('╚═══════════════════════════════════════╝');

  // 1. 环境检查
  checkEnvironment();

  // 2. 凭证配置
  if (!depsOnly) {
    const credOk = await setupCredentials(reset);
    if (!credOk) {
      console.error('\n[ERROR] 凭证配置失败，请重新运行 setup.js');
      process.exit(1);
    }
  }

  // 3. 安装依赖
  installDependencies();

  // 4. 完成
  console.log('\n═══════════════════════════════════════');
  console.log('  初始化完成!');
  console.log('═══════════════════════════════════════');
  console.log('');
  console.log('技能列表:');
  console.log('  - tiangong-prototype-spec  原型设计规范（可替换）');
  console.log('  - fuxi-packager            伏羲平台打包上传');
  console.log('  - deployment-validator     部署验证');
  console.log('');
  console.log('凭证文件位置:', credentials.getCredentialsPath());
  console.log('如需重新配置凭证: node setup.js --reset');
  console.log('');
}

main().catch(err => {
  console.error('[ERROR]', err.message);
  process.exit(1);
});
