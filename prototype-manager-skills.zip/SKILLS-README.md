# 原型设计技能包使用说明

> **更新日期**：2026-06-15
> **适用 Agent**：KimiCode / WorkBuddy 环境下的原型设计 Agent

---

## 快速开始

### 1. 初始化（首次使用必须执行）

```bash
node .agents/skills/setup.js
```

初始化脚本会完成以下工作：
- **环境检查** — 检测 Node.js、npm、PowerShell、Git 是否可用
- **凭证配置** — 引导输入伏羲平台地址、用户名、密码，存储到 `~/.fuxi-credentials.json`
- **依赖安装** — 自动安装技能所需的所有 npm 依赖（如 `adm-zip`）

### 2. 加载技能

生成原型前，先加载设计规范：

```
skill: tiangong-prototype-spec
```

如需打包部署，额外加载：

```
skill: fuxi-packager
skill: deployment-validator
```

---

## 技能清单

### 1. tiangong-prototype-spec（原型设计规范）

**用途**：定义前端原型的视觉风格、组件模式、布局规范和交互模式

> **可替换**：此技能的内容可由使用者自行替换为自己的设计规范。
> 目录结构保持不变（`SKILL.md` + `references/*.md`），内容完全自定义。

**触发场景**：
- 生成任何需要遵循特定设计系统的页面原型
- 需要遵循特定的组件、颜色、布局规范

**参考文件**（位于 `tiangong-prototype-spec/references/` 下）：
- 颜色体系
- 布局模式
- 组件模式
- 交互模式
- 原型说明系统（如适用）

**依赖**：无（纯文档规范）

**如何替换为自己的规范**：
1. 备份当前 `tiangong-prototype-spec/` 目录
2. 将你自己的规范文件放入该目录，保持 `SKILL.md` 作为主入口
3. 在 `references/` 子目录下放置参考文件
4. Agent 加载 `skill: tiangong-prototype-spec` 时会自动读取你替换后的内容

---

### 2. fuxi-packager（伏羲平台打包上传）

**用途**：将前端项目打包为 ZIP 并上传至伏羲平台

**触发场景**：
- 前端原型开发完成后需要部署到伏羲平台
- 需要生成符合伏羲平台规范的 ZIP 包

**功能**：
- 自动终止开发服务器
- 自动构建（检测 build 脚本）
- 使用 `adm-zip` 打包为标准化 ZIP
- 从本地凭证读取伏羲平台账号（支持凭证失效自动重输）
- 创建/查找原型并上传
- 验证 README 提取

**凭证管理**：
- 凭证存储在 `~/.fuxi-credentials.json`，每位使用者独立配置
- 登录失败时自动清除旧凭证并提示重新输入
- 重新配置: `node setup.js --reset`

**依赖**：`adm-zip`（通过 `setup.js` 自动安装）

---

### 3. deployment-validator（部署验证器）

**用途**：验证前端项目/ZIP包是否符合伏羲平台部署要求

**触发场景**：
- 部署前检查项目配置
- 打包前验证构建产物
- 排查部署后的白屏或路径错误

**功能**：
- Project 模式：检查构建产物、HTML路径、Vite配置
- ZIP 模式：解压检查入口文件、禁止目录、文件大小
- 输出检查报告和修复建议

**依赖**：无（使用 Node.js 内置模块 + PowerShell）

---

## 目录结构

```
.agents/skills/
├── setup.js                              # 初始化脚本（凭证配置 + 依赖安装）
├── shared/
│   └── credentials.js                    # 共享凭证管理模块
├── tiangong-prototype-spec/              # 原型设计规范（可替换）
│   ├── SKILL.md                          # 主规范文件（入口）
│   └── references/                       # 参考文件目录
│       ├── color-palette.md
│       ├── layout-patterns.md
│       ├── component-patterns.md
│       ├── interaction-patterns.md
│       └── prototype-annotation.md
├── fuxi-packager/                        # 伏羲平台打包上传
│   ├── SKILL.md
│   ├── pack-and-upload.js                # 主脚本
│   ├── package.json
│   └── node_modules/adm-zip/
├── deployment-validator/                 # 部署验证
│   ├── SKILL.md
│   ├── scripts/
│   │   ├── validate.js
│   │   └── pack-for-deployment.js
│   └── references/
│       └── deployment-guide.md
└── SKILLS-README.md                      # 本文件
```

---

## 更新记录

| 日期 | 操作 | 说明 |
|------|------|------|
| 2026-06-15 | 支持动态原型规范 | `tiangong-prototype-spec` 内容可由使用者替换；移除 SKILLS-README 中硬编码的设计值 |
| 2026-06-15 | 重构技能体系 | 新增 `setup.js` 初始化脚本、`shared/credentials.js` 凭证模块；移除 fuxi-packager 硬编码凭证 |
| 2026-06-15 | 重写 deployment-validator | 适配伏羲平台实际行为（自动注入 base 标签、智能目录展平） |

---

## 给原型设计 Agent 的完整工作流

当你接到"生成 XXX 原型"的任务时：

1. **加载 skill**：`skill: tiangong-prototype-spec`
2. **读取规范**：阅读 `tiangong-prototype-spec/SKILL.md` 和 `references/` 下的参考文件，提取当前项目使用的设计规范
3. **确认需求**：与主 agent 确认业务功能需求
4. **生成原型**：严格遵循读取到的设计规范生成原型代码
5. **自检**：对照规范中的检查清单逐项确认
6. **（可选）打包部署**：加载 `fuxi-packager` 和 `deployment-validator`

---

> 具体设计规范以 `tiangong-prototype-spec/SKILL.md` 的内容为准。
