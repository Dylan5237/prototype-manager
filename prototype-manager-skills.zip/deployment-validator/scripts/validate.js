/**
 * Fuxi Deployment Validator
 * Validates frontend projects or ZIP files before uploading to Fuxi platform.
 *
 * Usage:
 *   node validate.js project <project-path>   — validate a project directory
 *   node validate.js zip <zip-path>           — validate a ZIP file
 *
 * Exit codes: 0 = all passed, 1 = has errors
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ── Colors ──────────────────────────────────────────────────────────────────
const c = {
  reset: '\x1b[0m', green: '\x1b[32m', red: '\x1b[31m',
  yellow: '\x1b[33m', cyan: '\x1b[36m', gray: '\x1b[90m',
};
function log(level, msg) {
  const p = { INFO: c.cyan, PASS: c.green, FAIL: c.red, WARN: c.yellow, FIX: c.yellow };
  console.log(`${p[level] ? `${p[level]}[${level}]${c.reset}` : '[???]'} ${msg}`);
}

// ── Entry file candidates (matches Fuxi backend logic) ──────────────────────
const ENTRY_CANDIDATES = [
  'dist/index.html',
  'build/index.html',
  'index.html',
  'public/index.html',
];

const FORBIDDEN_DIRS = ['node_modules', '.git', '.svn', 'src', '__tests__', 'tests'];
const MAX_ZIP_SIZE = 100 * 1024 * 1024; // 100 MB

// ── Helpers ─────────────────────────────────────────────────────────────────

function findEntryFile(dir) {
  for (const candidate of ENTRY_CANDIDATES) {
    if (fs.existsSync(path.join(dir, candidate))) {
      return candidate;
    }
  }
  return null;
}

function checkHtmlPaths(htmlPath) {
  const content = fs.readFileSync(htmlPath, 'utf-8');
  const issues = [];

  // Check for source references (dev mode HTML)
  if (content.includes('src="/src/') || content.includes('src=\'/src/')) {
    issues.push({ level: 'FAIL', msg: 'HTML references source files (/src/) — this is the dev HTML, not the built version' });
  }

  // Check for absolute asset paths
  if (/src="\/assets\//.test(content) || /href="\/assets\//.test(content)) {
    issues.push({ level: 'WARN', msg: 'Absolute asset paths detected (/assets/). Fuxi auto-fixes this, but relative paths (./assets/) are more reliable' });
  }

  // Check for relative asset paths (good)
  if (/src="\.\//.test(content) || /href="\.\//.test(content)) {
    issues.push({ level: 'PASS', msg: 'Relative asset paths detected (./)' });
  }

  return issues;
}

function checkViteConfig(projectPath) {
  const configNames = ['vite.config.ts', 'vite.config.js', 'vite.config.mts', 'vite.config.mjs'];
  let configPath = null;
  for (const name of configNames) {
    const p = path.join(projectPath, name);
    if (fs.existsSync(p)) { configPath = p; break; }
  }
  if (!configPath) return [{ level: 'WARN', msg: 'No vite.config found (may not be a Vite project)' }];

  const content = fs.readFileSync(configPath, 'utf-8');
  const issues = [];

  if (/base:\s*['"]\.\/['"]/.test(content)) {
    issues.push({ level: 'PASS', msg: `base: './' set in ${path.basename(configPath)}` });
  } else if (/base:\s*['"]\/['"]/.test(content)) {
    issues.push({ level: 'WARN', msg: `base: '/' in ${path.basename(configPath)} — Fuxi auto-fixes, but './' is safer` });
  } else {
    issues.push({ level: 'WARN', msg: `No explicit base in ${path.basename(configPath)} (defaults to '/') — consider adding base: './'` });
  }
  return issues;
}

function dirHasForbiddenContent(dir) {
  const issues = [];
  for (const forbidden of FORBIDDEN_DIRS) {
    if (fs.existsSync(path.join(dir, forbidden))) {
      const severity = forbidden === 'node_modules' ? 'FAIL' : 'WARN';
      issues.push({ level: severity, msg: `Found "${forbidden}/" — should not be in upload package` });
    }
  }
  return issues;
}

// ── Project Directory Validation ────────────────────────────────────────────

function validateProject(projectPath) {
  const absPath = path.resolve(projectPath);
  console.log(`\n${c.cyan}═══ Fuxi Validator — Project Mode ═══${c.reset}`);
  console.log(`Project: ${absPath}\n`);

  let passed = true;

  // 1. Check build output
  log('INFO', 'Checking build output...');
  const entry = findEntryFile(absPath);
  if (entry) {
    log('PASS', `Entry file found: ${entry}`);
  } else {
    log('FAIL', 'No entry file found (checked: ' + ENTRY_CANDIDATES.join(', ') + ')');
    log('FIX', 'Run "npm run build" first');
    passed = false;
  }

  // 2. Check HTML content
  if (entry) {
    log('INFO', 'Checking HTML resource paths...');
    const htmlIssues = checkHtmlPaths(path.join(absPath, entry));
    for (const issue of htmlIssues) {
      log(issue.level, issue.msg);
      if (issue.level === 'FAIL') passed = false;
    }
  }

  // 3. Check vite config
  log('INFO', 'Checking vite configuration...');
  for (const issue of checkViteConfig(absPath)) {
    log(issue.level, issue.msg);
    if (issue.level === 'FAIL') passed = false;
  }

  // 4. Check for forbidden content
  log('INFO', 'Checking for forbidden content...');
  const forbidden = dirHasForbiddenContent(absPath);
  if (forbidden.length === 0) {
    log('PASS', 'No forbidden directories found');
  } else {
    for (const issue of forbidden) {
      log(issue.level, issue.msg);
      if (issue.level === 'FAIL') passed = false;
    }
  }

  // Summary
  printSummary(passed);
  return passed;
}

// ── ZIP File Validation ─────────────────────────────────────────────────────

function validateZip(zipPath) {
  const absZip = path.resolve(zipPath);
  console.log(`\n${c.cyan}═══ Fuxi Validator — ZIP Mode ═══${c.reset}`);
  console.log(`ZIP: ${absZip}\n`);

  let passed = true;

  // 1. File exists
  if (!fs.existsSync(absZip)) {
    log('FAIL', `ZIP file not found: ${absZip}`);
    printSummary(false);
    return false;
  }

  // 2. File size
  const stats = fs.statSync(absZip);
  if (stats.size > MAX_ZIP_SIZE) {
    log('FAIL', `ZIP too large: ${(stats.size / 1024 / 1024).toFixed(1)} MB (max 100 MB)`);
    passed = false;
  } else {
    log('PASS', `ZIP size OK: ${(stats.size / 1024 / 1024).toFixed(1)} MB`);
  }

  // 3. Extract to temp dir and check contents
  const tempDir = path.join(path.dirname(absZip), `.fuxi-validate-${Date.now()}`);
  try {
    fs.mkdirSync(tempDir, { recursive: true });
    execSync(`powershell -Command "Expand-Archive -Path '${absZip}' -DestinationPath '${tempDir}' -Force"`, { stdio: 'pipe' });

    // Find entry file (handle nested single-folder case)
    log('INFO', 'Checking ZIP contents for entry file...');
    let entryDir = tempDir;
    const rootItems = fs.readdirSync(tempDir);

    // Check if single wrapper folder
    if (rootItems.length === 1) {
      const singleItem = path.join(tempDir, rootItems[0]);
      if (fs.statSync(singleItem).isDirectory()) {
        log('INFO', `Single wrapper folder detected: ${rootItems[0]}/`);
        entryDir = singleItem;
      }
    }

    const entry = findEntryFile(entryDir);
    if (entry) {
      log('PASS', `Entry file found: ${entry}`);
    } else {
      // Try one level deeper (multi-item case)
      let found = false;
      for (const item of rootItems) {
        const subDir = path.join(tempDir, item);
        if (fs.statSync(subDir).isDirectory()) {
          const subEntry = findEntryFile(subDir);
          if (subEntry) {
            log('PASS', `Entry file found in subdirectory: ${item}/${subEntry}`);
            found = true;
            break;
          }
        }
      }
      if (!found) {
        log('FAIL', 'No entry file found in ZIP');
        log('FIX', 'Ensure ZIP contains dist/index.html or index.html');
        passed = false;
      }
    }

    // Check for forbidden content
    log('INFO', 'Checking for forbidden content...');
    const forbidden = dirHasForbiddenContent(entryDir);
    if (forbidden.length === 0) {
      log('PASS', 'No forbidden directories in ZIP');
    } else {
      for (const issue of forbidden) {
        log(issue.level, issue.msg);
        if (issue.level === 'FAIL') passed = false;
      }
    }

    // Check HTML paths
    if (entry) {
      log('INFO', 'Checking HTML resource paths...');
      const htmlIssues = checkHtmlPaths(path.join(entryDir, entry));
      for (const issue of htmlIssues) {
        log(issue.level, issue.msg);
        if (issue.level === 'FAIL') passed = false;
      }
    }

    // List ZIP structure
    log('INFO', 'ZIP structure:');
    listDir(entryDir, '  ', 2);

  } catch (err) {
    log('FAIL', `Failed to extract ZIP: ${err.message}`);
    passed = false;
  } finally {
    // Cleanup
    if (fs.existsSync(tempDir)) {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  }

  printSummary(passed);
  return passed;
}

function listDir(dir, indent, maxDepth) {
  if (maxDepth <= 0) return;
  const items = fs.readdirSync(dir);
  for (const item of items.slice(0, 15)) { // limit output
    const fullPath = path.join(dir, item);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      console.log(`${indent}${c.gray}${item}/${c.reset}`);
      listDir(fullPath, indent + '  ', maxDepth - 1);
    } else {
      const size = stat.size > 1024 ? `${(stat.size / 1024).toFixed(0)}K` : `${stat.size}B`;
      console.log(`${indent}${item} ${c.gray}(${size})${c.reset}`);
    }
  }
  if (items.length > 15) {
    console.log(`${indent}${c.gray}... and ${items.length - 15} more${c.reset}`);
  }
}

// ── Summary ─────────────────────────────────────────────────────────────────

function printSummary(passed) {
  console.log(`\n${c.cyan}═══ Result ═══${c.reset}`);
  if (passed) {
    log('PASS', 'All checks passed! Ready for Fuxi upload.');
  } else {
    log('FAIL', 'Issues found. Fix before uploading to Fuxi.');
  }
  console.log('');
}

// ── Main ────────────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
if (args.length < 2 || !['project', 'zip'].includes(args[0])) {
  console.log('Usage:');
  console.log('  node validate.js project <project-path>   — validate project directory');
  console.log('  node validate.js zip <zip-path>           — validate ZIP file');
  console.log('');
  console.log('Examples:');
  console.log('  node validate.js project .');
  console.log('  node validate.js project D:\\projects\\my-app');
  console.log('  node validate.js zip D:\\temp\\prototype.zip');
  process.exit(1);
}

const mode = args[0];
const target = args[1];

let success;
if (mode === 'project') {
  success = validateProject(target);
} else {
  success = validateZip(target);
}

process.exit(success ? 0 : 1);
