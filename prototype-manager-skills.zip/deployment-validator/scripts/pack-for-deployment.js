/**
 * Fuxi Pack for Deployment
 * Packages a frontend project into a ZIP ready for Fuxi platform upload.
 *
 * Usage: node pack-for-deployment.js <project-path> <output-zip-path>
 *
 * What it does:
 * 1. Validates project (build output, paths, config)
 * 2. Packages only dist/ contents (index.html at ZIP root)
 * 3. Verifies the resulting ZIP
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ── Colors ──────────────────────────────────────────────────────────────────
const c = {
  reset: '\x1b[0m', green: '\x1b[32m', red: '\x1b[31m',
  yellow: '\x1b[33m', cyan: '\x1b[36m', gray: '\x1b[90m',
};
function log(level, msg) {
  const p = { INFO: c.cyan, PASS: c.green, FAIL: c.red, WARN: c.yellow, FIX: c.yellow };
  console.log(`${p[level] ? `${p[level]}[${level}]${c.reset}` : '[???]'} ${msg}`);
}

// ── Entry file detection (matches Fuxi backend) ─────────────────────────────
const ENTRY_CANDIDATES = ['dist/index.html', 'build/index.html', 'index.html', 'public/index.html'];

function findBuildDir(projectPath) {
  for (const candidate of ENTRY_CANDIDATES) {
    const fullPath = path.join(projectPath, candidate);
    if (fs.existsSync(fullPath)) {
      return { dir: path.dirname(candidate), entry: candidate };
    }
  }
  return null;
}

// ── Copy directory recursively ──────────────────────────────────────────────
function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const file of fs.readdirSync(src)) {
    const s = path.join(src, file);
    const d = path.join(dest, file);
    if (fs.statSync(s).isDirectory()) {
      copyDir(s, d);
    } else {
      fs.copyFileSync(s, d);
    }
  }
}

// ── Main ────────────────────────────────────────────────────────────────────
const args = process.argv.slice(2);
if (args.length < 2) {
  console.log('Usage: node pack-for-deployment.js <project-path> <output-zip-path>');
  console.log('Example: node pack-for-deployment.js . D:\\temp\\prototype.zip');
  process.exit(1);
}

const projectPath = path.resolve(args[0]);
const outputPath = path.resolve(args[1]);

console.log(`\n${c.cyan}═══ Fuxi Pack for Deployment ═══${c.reset}`);
console.log(`Project: ${projectPath}`);
console.log(`Output:  ${outputPath}\n`);

// Step 1: Find build output
log('INFO', 'Looking for build output...');
const buildResult = findBuildDir(projectPath);
if (!buildResult) {
  log('FAIL', 'No build output found (checked: ' + ENTRY_CANDIDATES.join(', ') + ')');
  log('FIX', 'Run "npm run build" first');
  process.exit(1);
}
log('PASS', `Build output found: ${buildResult.entry}`);

// Step 2: Validate HTML paths
const buildDir = path.join(projectPath, buildResult.dir);
const htmlPath = path.join(buildDir, 'index.html');
const htmlContent = fs.readFileSync(htmlPath, 'utf-8');

if (htmlContent.includes('src="/src/') || htmlContent.includes("src='/src/")) {
  log('FAIL', 'HTML references source files (/src/) — this is dev HTML, not built output');
  log('FIX', 'Run "npm run build" to generate proper build output');
  process.exit(1);
}

if (/src="\/assets\//.test(htmlContent) || /href="\/assets\//.test(htmlContent)) {
  log('WARN', 'Absolute asset paths detected (/assets/). Fuxi auto-fixes this, but "./" is safer');
  log('FIX', 'Set base: "./" in vite.config.ts, then re-run npm run build');
} else {
  log('PASS', 'Asset paths look good');
}

// Step 3: Prepare temp directory with build contents
log('INFO', 'Preparing package...');
const tempDir = path.join(path.dirname(outputPath), `.fuxi-pack-${Date.now()}`);
fs.mkdirSync(tempDir, { recursive: true });

// Copy build directory contents to temp (promote to ZIP root)
copyDir(buildDir, tempDir);

// Step 4: Create ZIP
log('INFO', 'Creating ZIP...');
try {
  // Remove existing output if present
  if (fs.existsSync(outputPath)) {
    fs.unlinkSync(outputPath);
  }
  execSync(`powershell -Command "Compress-Archive -Path '${tempDir}\\*' -DestinationPath '${outputPath}' -Force"`, { stdio: 'pipe' });
} catch (err) {
  log('FAIL', `Failed to create ZIP: ${err.message}`);
  fs.rmSync(tempDir, { recursive: true, force: true });
  process.exit(1);
}

// Cleanup temp
fs.rmSync(tempDir, { recursive: true, force: true });

// Step 5: Verify ZIP
const zipStats = fs.statSync(outputPath);
const sizeMB = (zipStats.size / 1024 / 1024).toFixed(1);

if (zipStats.size > 100 * 1024 * 1024) {
  log('FAIL', `ZIP too large: ${sizeMB} MB (Fuxi max is 100 MB)`);
  process.exit(1);
}

log('PASS', `ZIP created: ${path.basename(outputPath)} (${sizeMB} MB)`);

// Verify ZIP contents
const verifyDir = path.join(path.dirname(outputPath), `.fuxi-verify-${Date.now()}`);
try {
  fs.mkdirSync(verifyDir, { recursive: true });
  execSync(`powershell -Command "Expand-Archive -Path '${outputPath}' -DestinationPath '${verifyDir}' -Force"`, { stdio: 'pipe' });

  // Check entry file in ZIP
  let foundEntry = false;
  for (const candidate of ENTRY_CANDIDATES) {
    if (fs.existsSync(path.join(verifyDir, candidate))) {
      log('PASS', `Entry file verified in ZIP: ${candidate}`);
      foundEntry = true;
      break;
    }
  }
  if (!foundEntry) {
    log('WARN', 'Could not verify entry file in ZIP — please check manually');
  }

  // List ZIP contents (brief)
  log('INFO', 'ZIP contents:');
  const items = fs.readdirSync(verifyDir);
  for (const item of items) {
    const stat = fs.statSync(path.join(verifyDir, item));
    if (stat.isDirectory()) {
      const subItems = fs.readdirSync(path.join(verifyDir, item));
      console.log(`  ${c.gray}${item}/${c.reset} (${subItems.length} files)`);
    } else {
      console.log(`  ${item}`);
    }
  }
} catch (err) {
  log('WARN', `Could not verify ZIP contents: ${err.message}`);
} finally {
  if (fs.existsSync(verifyDir)) {
    fs.rmSync(verifyDir, { recursive: true, force: true });
  }
}

// Done
console.log(`\n${c.cyan}═══ Packaging Complete ═══${c.reset}`);
log('PASS', `Ready for Fuxi upload: ${outputPath}`);
console.log('');
