# Fuxi Platform Deployment Guide

Deploy frontend prototypes to the Fuxi prototype management platform (伏羲原型管理平台).

## How Fuxi Works

### Upload Flow

1. User uploads a `.zip` file (max 100 MB)
2. Fuxi extracts ZIP into `repos/<prototype-id>/`
3. Fuxi auto-detects entry file (priority: `dist/index.html` → `build/index.html` → `index.html` → `public/index.html`)
4. Fuxi auto-flattens single-wrapper-folder ZIP structures
5. Preview served via `/preview/<id>/<entry-file>` with auto-injected `<base>` tag

### Path Auto-Fix

Fuxi's preview route automatically:
- Injects `<base href="/preview/<id>/...">` into served HTML
- Converts absolute paths (`/assets/xxx.js`) to relative paths in HTML content

This means **absolute paths usually work on Fuxi**, but relative paths (`base: './'`) are still recommended as best practice.

## Pre-Upload Checklist

- [ ] Project built successfully (`npm run build`)
- [ ] Build output exists (`dist/` or `build/` with `index.html`)
- [ ] No `node_modules/` or `src/` in the package
- [ ] ZIP file ≤ 100 MB
- [ ] Entry file detectable (`dist/index.html` preferred)

## Step-by-Step Deployment

### 1. Build

```bash
npm run build
```

Verify output:
```bash
ls dist/
# Should see: index.html  assets/
```

### 2. Validate

```bash
# Validate project directory
node scripts/validate.js project .

# Or validate an existing ZIP
node scripts/validate.js zip prototype.zip
```

### 3. Package

```bash
# Recommended: use pack script
node scripts/pack-for-deployment.js . prototype.zip

# Or manual PowerShell
cd dist
Compress-Archive -Path * -DestinationPath ..\prototype.zip -Force
cd ..
```

### 4. Upload

Upload the ZIP via the Fuxi web interface or API.

### 5. Verify

After upload, click the preview button to verify the prototype loads correctly.

## Troubleshooting

### White Screen

**Symptoms**: Blank page, no errors in console.

**Causes & fixes**:
1. Wrong `index.html` packaged (dev version instead of built)
   - Fix: Ensure you package from `dist/`, not project root
2. JavaScript runtime error
   - Fix: Open DevTools → Console tab, check for errors
3. Vue/React app not mounting
   - Fix: Check if `#app` div exists in HTML

### 404 on Assets

**Symptoms**: Page loads but unstyled/broken, Network shows 404 for JS/CSS.

**Causes & fixes**:
1. Absolute paths in built HTML (`/assets/xxx.js`)
   - Fix: Set `base: './'` in `vite.config.ts`, rebuild
   - Note: Fuxi auto-fixes this, but relative paths are more reliable

### "Entry File Not Found" / Preview Disabled

**Symptoms**: Upload succeeds but preview button is disabled.

**Causes & fixes**:
1. No recognizable entry file in ZIP
   - Fix: Ensure ZIP contains `dist/index.html` or `index.html`
2. ZIP structure too nested (multiple wrapper folders)
   - Fix: Use `pack-for-deployment.js` which packages `dist/` contents directly

### ZIP Too Large

**Symptoms**: Upload fails with size error.

**Causes & fixes**:
1. Included `node_modules/` or source code
   - Fix: Only package `dist/` contents
2. Source maps included
   - Fix: Add `build: { sourcemap: false }` to `vite.config.ts`

### Build Fails

**Common errors**:
- `npm run build` fails → Check terminal output for TypeScript/syntax errors
- Out of memory → Set `$env:NODE_OPTIONS="--max-old-space-size=4096"` (PowerShell)
- Chunk size warning → Add `chunkSizeWarningLimit: 1000` to vite.config build options

## Vite Configuration Best Practices

```typescript
// vite.config.ts
export default defineConfig({
  base: './',  // Relative paths for subpath deployment
  build: {
    outDir: 'dist',
    sourcemap: false,  // Reduce ZIP size
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['vue', 'element-plus'],  // Split vendor chunk
        },
      },
    },
  },
  // ...
})
```

## References

- [Vite Static Deployment](https://vitejs.dev/guide/static-deploy.html)
- [Vue 3 Production Deployment](https://vuejs.org/guide/best-practices/production-deployment.html)
