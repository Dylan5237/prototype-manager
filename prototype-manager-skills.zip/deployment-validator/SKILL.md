---
name: deployment-validator
description: Validate and package frontend prototypes before uploading to Fuxi platform (伏羲原型管理平台). Use when user asks to deploy, upload, package, or troubleshoot a prototype for Fuxi. Triggered by keywords like "deploy", "upload prototype", "package for Fuxi", "打包", "上传原型", "白屏", "404".
---

# Deployment Validator (Fuxi Platform)

Validate and package frontend prototypes for the Fuxi prototype management platform (伏羲原型管理平台).

## When to Use

Trigger this skill when:
- User asks to deploy/upload/package a prototype to Fuxi
- Troubleshooting white screen, 404, or "entry file not found" after upload
- Before running any pack-and-upload workflow
- Keywords: "deploy", "upload prototype", "打包", "上传原型", "白屏", "404"

## Fuxi Platform Requirements

### What Fuxi Actually Requires

| Requirement | Details |
|---|---|
| File format | `.zip` only |
| Max file size | **100 MB** |
| Entry file | Must contain a recognizable entry file (see priority below) |
| No `node_modules/` | Must NOT include `node_modules/` (wastes space, causes issues) |
| No `src/` | Should NOT include source code (security + size) |

### Entry File Detection Priority

Fuxi searches for entry files in this order:
1. `dist/index.html` (Vite/Webpack build output) ← **recommended**
2. `build/index.html` (alternative build output)
3. `index.html` (root-level, e.g. plain HTML prototypes)
4. `public/index.html` (Vue CLI / CRA style)

If none found → preview button disabled, prototype unusable.

### Smart Nested Directory Handling

Fuxi auto-flattens nested ZIP structures:
- **Single wrapper folder**: If ZIP has exactly one directory at root, its contents are promoted to root
- **Multiple items**: If one subdirectory contains an entry file, its contents are promoted

This means both structures work:
```
# Structure A: dist/ at root (recommended)
prototype.zip
├── dist/
│   ├── index.html
│   └── assets/

# Structure B: flat (also works)
prototype.zip
├── index.html
└── assets/

# Structure C: wrapper folder (also works, auto-flattened)
prototype.zip
└── my-project/
    ├── dist/
    │   └── index.html
    └── assets/
```

### Path Handling (Auto-Fixed by Fuxi)

Fuxi's preview route automatically:
- Injects `<base href="/preview/<id>/...">` into HTML
- Converts absolute paths (`/assets/xxx.js`) to relative paths

**However**, relying on auto-fix is risky. Best practice is still `base: './'` in vite.config.

## Quick Start

### Validate a project directory

```bash
node "<skill-path>/scripts/validate.js" project <project-path>
```

### Validate a ZIP file

```bash
node "<skill-path>/scripts/validate.js" zip <zip-path>
```

### Package for upload

```bash
node "<skill-path>/scripts/pack-for-deployment.js" <project-path> <output-zip-path>
```

Where `<skill-path>` is the directory containing this SKILL.md.

## Validation Checklist

### For Project Directory

1. **Build output exists**: `dist/` or `build/` directory with `index.html`
2. **No source leaks**: No `node_modules/` or `src/` would be packaged
3. **Resource paths**: `dist/index.html` uses relative paths (`./assets/`) — warn if absolute
4. **vite.config**: Has `base: './'` — warn if missing or set to `'/'`

### For ZIP File

1. **File exists and is valid ZIP**
2. **Size ≤ 100 MB**
3. **Contains entry file**: Check all 4 candidate locations
4. **No forbidden content**: No `node_modules/`, no `src/`
5. **Entry HTML references valid assets**: JS/CSS files referenced in HTML actually exist in ZIP

## Common Issues and Fixes

### White Screen After Upload

**Cause**: Wrong `index.html` served (source version instead of built version), or JS error.

**Fix**:
1. Ensure `dist/` exists with built `index.html`
2. Check `dist/index.html` references `./assets/xxx.js`, not `/src/main.ts`
3. Re-package only `dist/` contents

### 404 on JS/CSS Files

**Cause**: Absolute paths (`/assets/xxx.js`) when served from subpath.

**Fix**:
1. Set `base: './'` in `vite.config.ts`
2. Re-run `npm run build`
3. Fuxi auto-fixes this, but relative paths are more reliable

### "Entry File Not Found" / Preview Disabled

**Cause**: No recognizable entry file in ZIP.

**Fix**:
1. Run `node validate.js zip prototype.zip` to check
2. Ensure ZIP contains `dist/index.html` or `index.html`
3. Re-package using `pack-for-deployment.js`

### ZIP Too Large (>100MB)

**Cause**: Accidentally included `node_modules/` or source maps.

**Fix**:
1. Only package `dist/` directory contents
2. Disable source maps in vite.config: `build.sourcemap: false`

## Scripts

### validate.js

Two modes:

```bash
# Validate project directory (pre-build check)
node scripts/validate.js project <project-path>

# Validate ZIP file (pre-upload check)
node scripts/validate.js zip <zip-path>
```

**Exit codes**: 0 = all passed, 1 = has errors (must fix before upload)

### pack-for-deployment.js

Packages a project for Fuxi upload:

```bash
node scripts/pack-for-deployment.js <project-path> <output-zip-path>
```

This script:
1. Validates project first (runs same checks as validate.js)
2. Only packages `dist/` contents
3. Ensures `index.html` is at ZIP root
4. Reports ZIP structure and entry file detection result

## References

See `references/deployment-guide.md` for detailed Fuxi deployment procedures.
